# Fashion-MNIST CNN Classifier
# Required libraries
library(keras)
library(tensorflow)
library(ggplot2)

# Set random seeds for reproducibility
set.seed(42)
tensorflow::set_random_seed(42)

fashion_mnist_classifier <- function() {
  # Load Fashion-MNIST dataset
  cat("Loading Fashion-MNIST dataset...\n")
  fashion_mnist <- dataset_fashion_mnist()
  
  # Preprocess data
  x_train <- fashion_mnist$train$x / 255
  x_test <- fashion_mnist$test$x / 255
  
  # Reshape for CNN
  x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
  x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))
  
  # Convert labels to categorical
  y_train <- to_categorical(fashion_mnist$train$y, 10)
  y_test <- to_categorical(fashion_mnist$test$y, 10)
  
  # Build 6-layer CNN model
  cat("Building 6-layer CNN model...\n")
  model <- keras_model_sequential() %>%
    # Layer 1: Convolutional
    layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', 
                  input_shape = c(28, 28, 1)) %>%
    # Layer 2: Pooling
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # Layer 3: Convolutional
    layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
    # Layer 4: Pooling
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # Layer 5: Flatten + Dense
    layer_flatten() %>%
    layer_dense(units = 128, activation = 'relu') %>%
    layer_dropout(rate = 0.5) %>%
    # Layer 6: Output
    layer_dense(units = 10, activation = 'softmax')
  
  # Compile model
  model %>% compile(
    optimizer = 'adam',
    loss = 'categorical_crossentropy',
    metrics = c('accuracy')
  )
  
  # Train model
  cat("Training model...\n")
  history <- model %>% fit(
    x_train, y_train,
    batch_size = 128,
    epochs = 10,
    validation_data = list(x_test, y_test),
    verbose = 1
  )
  
  # Evaluate model
  cat("Evaluating model...\n")
  evaluation <- model %>% evaluate(x_test, y_test, verbose = 0)
  cat(sprintf("Test accuracy: %.4f\n", evaluation[2]))
  cat(sprintf("Test loss: %.4f\n", evaluation[1]))
  
  # Make predictions
  cat("Making predictions on sample images...\n")
  class_names <- c('T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
                   'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot')
  
  # Sample predictions
  sample_indices <- sample(1:nrow(x_test), 2)
  for (i in sample_indices) {
    prediction <- model %>% predict(x_test[i,,, drop = FALSE], verbose = 0)
    predicted_class <- which.max(prediction) - 1
    true_class <- which.max(y_test[i,]) - 1
    
    cat(sprintf("Image %d:\n", which(sample_indices == i)))
    cat(sprintf("  True class: %s (%d)\n", class_names[true_class + 1], true_class))
    cat(sprintf("  Predicted class: %s (%d)\n", class_names[predicted_class + 1], predicted_class))
    cat(sprintf("  Confidence: %.4f\n", max(prediction)))
    cat(sprintf("  Correct: %s\n", true_class == predicted_class))
    cat("\n")
  }
  
  # Save model
  save_model_tf(model, "fashion_mnist_cnn_r")
  cat("Model saved as 'fashion_mnist_cnn_r'\n")
  
  return(list(model = model, history = history))
}

# Execute the classifier
fashion_mnist_classifier()